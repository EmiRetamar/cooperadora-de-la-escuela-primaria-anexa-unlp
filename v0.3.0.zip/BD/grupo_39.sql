-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 19-10-2015 a las 12:20:18
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `grupo_39`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE IF NOT EXISTS `alumno` (
`id` int(10) unsigned NOT NULL,
  `tipoDocumento` varchar(50) NOT NULL,
  `numeroDocumento` int(10) unsigned NOT NULL,
  `apellido` text NOT NULL,
  `nombre` text NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `sexo` char(1) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `fechaIngreso` date NOT NULL,
  `fechaEgreso` date DEFAULT NULL,
  `fechaAlta` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`id`, `tipoDocumento`, `numeroDocumento`, `apellido`, `nombre`, `fechaNacimiento`, `sexo`, `mail`, `direccion`, `fechaIngreso`, `fechaEgreso`, `fechaAlta`) VALUES
(10, 'DNI', 36546888, 'Retamar', 'Emiliano', '2015-05-11', 'M', 'emiliano_retamar@hotmail.com.ar', 'alguna', '2015-10-02', NULL, '2015-10-19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnoResponsable`
--

CREATE TABLE IF NOT EXISTS `alumnoResponsable` (
  `idAlumno` int(10) unsigned NOT NULL,
  `idResponsable` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alumnoResponsable`
--

INSERT INTO `alumnoResponsable` (`idAlumno`, `idResponsable`) VALUES
(10, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configuracion`
--

CREATE TABLE IF NOT EXISTS `configuracion` (
  `titulo` varchar(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `elementos` int(100) NOT NULL,
  `habilitado` tinyint(1) NOT NULL,
  `mensajeEstado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `configuracion`
--

INSERT INTO `configuracion` (`titulo`, `descripcion`, `mail`, `elementos`, `habilitado`, `mensajeEstado`) VALUES
('Bienvenido 2015', 'Hoy es un buen dia', 'admin@anexa.com', 5, 1, 'Sitio en mantenimiento, por favor... reintente mas tarde.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuota`
--

CREATE TABLE IF NOT EXISTS `cuota` (
`id` int(10) unsigned NOT NULL,
  `anio` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `monto` int(11) NOT NULL,
  `tipo` int(11) NOT NULL,
  `comisionCobrador` int(11) NOT NULL,
  `fechaAlta` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cuota`
--

INSERT INTO `cuota` (`id`, `anio`, `mes`, `numero`, `monto`, `tipo`, `comisionCobrador`, `fechaAlta`) VALUES
(1, 2015, 1312312, 1213, 12312312, 1, 12, '3333-03-31'),
(2, 2010, 1312312, 1213, 12312312, 0, 12, '3333-03-31'),
(3, 2000, 2, 1213, 12312312, 0, 12, '3333-03-31'),
(8, 2015, 4, 5, 1500, 0, 90, '2015-01-01'),
(9, 2015, 4, 5, 1500, 0, 90, '2015-01-01'),
(10, 2015, 4, 5, 1500, 0, 90, '2015-01-01'),
(11, 2015, 4, 5, 1500, 0, 90, '2015-01-01'),
(12, 2015, 4, 5, 1500, 0, 90, '2015-01-01'),
(13, 2015, 4, 6, 1500, 0, 90, '2015-01-01'),
(14, 1993, 6, 12, 20100, 0, 20, '1111-11-11'),
(15, 1993, 25, 70, 15, 0, 13, '1111-11-11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE IF NOT EXISTS `pago` (
`id` int(10) unsigned NOT NULL,
  `idAlumno` int(11) unsigned NOT NULL,
  `idCuota` int(11) unsigned NOT NULL,
  `becado` tinyint(1) NOT NULL,
  `fechaAlta` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `pago`
--

INSERT INTO `pago` (`id`, `idAlumno`, `idCuota`, `becado`, `fechaAlta`) VALUES
(39, 10, 1, 1, '2015-10-10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable`
--

CREATE TABLE IF NOT EXISTS `responsable` (
`id` int(10) unsigned NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `idUsuario` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `responsable`
--

INSERT INTO `responsable` (`id`, `tipo`, `apellido`, `nombre`, `fechaNacimiento`, `sexo`, `mail`, `telefono`, `direccion`, `idUsuario`) VALUES
(1, 'tutor', 'Arana', 'Felipe', '2015-04-06', 'M', 'felipe@gmail.com', '022147483647', 'calee verdadera 123', NULL),
(2, 'madre', 'Gonzalez', 'Maria', '2015-03-17', 'F', 'maria@hotmail.com', '3524564132', 'deh', NULL),
(3, 'tutor', 'Messi', 'Lionel', '2015-07-15', 'M', 'messi@gmail.com', '1234235443', 'Barcelona', 16),
(4, 'tutor', 'Ronaldo', 'Cristiano', '2015-10-25', 'M', 'ronaldo@gmail.com', '23244345', 'Madrid', NULL),
(5, 'madre', 'Garay', 'Lola', '2015-11-27', 'F', 'lola@hotmail.com', '8129831822', 'Bariloche', NULL),
(6, 'tutor', 'Pastore', 'Javier', '2015-02-21', 'M', 'pastore@hotmail.com', '494399439', 'Paris', NULL),
(7, 'madre', 'mamadoupu', 'teresa', '2014-02-02', 'F', 'mama@mamalandia.com', '215487686', '70 nro 977 casa 2', NULL),
(8, 'padre', 'Papadopulus', 'david', '5798-05-11', 'M', 'fap@yourmama', '2154878984', 'asfa411', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
`id` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `habilitado` tinyint(1) NOT NULL,
  `rol` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `username`, `password`, `habilitado`, `rol`, `mail`) VALUES
(1, 'peter', '123456', 1, 'administrador', 'peter@gmail.com'),
(3, 'Emi', '123456', 1, 'administrador', 'emiliano_retamar@hotmail.com.ar'),
(4, 'pepito', '123456', 0, 'consulta', 'pepito@hotmail.com'),
(5, 'josesito', '123456', 1, 'consulta', 'jose@gmail.com'),
(11, ' josefina', '123456', 1, 'gestion', 'josefina@hotmail.com'),
(16, 'Messi', '123456', 1, 'consulta', 'messi@gmail.com');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `tipoDocumento/numeroDocumento` (`tipoDocumento`,`numeroDocumento`);

--
-- Indices de la tabla `alumnoResponsable`
--
ALTER TABLE `alumnoResponsable`
 ADD PRIMARY KEY (`idAlumno`,`idResponsable`), ADD KEY `idAlumno` (`idAlumno`), ADD KEY `idResponsable` (`idResponsable`);

--
-- Indices de la tabla `configuracion`
--
ALTER TABLE `configuracion`
 ADD PRIMARY KEY (`titulo`);

--
-- Indices de la tabla `cuota`
--
ALTER TABLE `cuota`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idAlumno/idCuota` (`idAlumno`,`idCuota`), ADD KEY `idAlumno` (`idAlumno`), ADD KEY `idCuota` (`idCuota`);

--
-- Indices de la tabla `responsable`
--
ALTER TABLE `responsable`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idUsuario` (`idUsuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumno`
--
ALTER TABLE `alumno`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `cuota`
--
ALTER TABLE `cuota`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT de la tabla `pago`
--
ALTER TABLE `pago`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT de la tabla `responsable`
--
ALTER TABLE `responsable`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumnoResponsable`
--
ALTER TABLE `alumnoResponsable`
ADD CONSTRAINT `alumnoResponsable_alumno` FOREIGN KEY (`idAlumno`) REFERENCES `alumno` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `alumnoResponsable_responsable` FOREIGN KEY (`idResponsable`) REFERENCES `responsable` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pago`
--
ALTER TABLE `pago`
ADD CONSTRAINT `pago_alumno` FOREIGN KEY (`idAlumno`) REFERENCES `alumno` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `pago_cuota` FOREIGN KEY (`idCuota`) REFERENCES `cuota` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `responsable`
--
ALTER TABLE `responsable`
ADD CONSTRAINT `responsable_usuario` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
