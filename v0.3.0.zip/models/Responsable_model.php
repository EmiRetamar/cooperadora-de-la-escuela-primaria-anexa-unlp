<?php

require_once 'PDOConnection.php';

class Responsable_model {

    private  $id;
    private  $tipo;
    private  $apellido;
    private  $nombre;
    private  $fechaNacimiento;
    private  $sexo;
    private  $mail;
    private  $telefono;
    private  $direccion;
    private  $idUsuario;
    private  $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getId() {
        return ($this->id);
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getTipo() {
        return ($this->tipo);
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function getApellido() {
        return ($this->apellido);
    }

    public function setApellido($apellido) {
        $this->apellido = $apellido;
    }

    public function getNombre() {
        return ($this->nombre);
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getFechaNacimiento() {
        return ($this->fechaNacimiento);
    }

    public function setFechaNacimiento($fechaNacimiento) {
        $this->fechaNacimiento = $fechaNacimiento;
    }

    public function getSexo($sexo) {
        return ($this->sexo);
    }

    public function setSexo($sexo) {
        $this->sexo = $sexo;
    }

    public function getMail() {
        return ($this->mail);
    }

    public function setMail($mail) {
        $this->mail = $mail;
    }

    public function getTelefono() {
        return ($this->telefono);
    }

    public function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    public function getDireccion() {
        return ($this->direccion);
    }

    public function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    public function getIdUsuario() {
        return ($this->idUsuario);
    }

    public function setIdUsuario($idUsuario) {
        $this->idUsuario = $idUsuario;
    }

    public function existeMailResponsable($mail) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT mail FROM responsable WHERE mail = :mail");
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexionn
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    public function obtenerIdResponsable($mail) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT id FROM responsable WHERE mail = :mail");
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt->fetchColumn()); // Lo que hace fetchColumn() es devolver una única columna de la siguiente fila de un conjunto de resultados. Por ejemplos si se tienen 2 filas y se lo usa la primera vez devuelve un dato de la primera fila y si se lo usa otra vez devuelve un dato de la segunda fila. Si se le ingresa un parametro fetchColumn(1) lo que hace es devolver la segunda columna de la siguiente fila. En este caso devuelve la primera columna de la primera fila porque se usa una vez y tenemos una sola fila
        }
        else {
            return (false);
        }
    }

    public function asignarCuenta($mail, $idUsuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("UPDATE responsable
            set
                idUsuario = :idUsuario
            WHERE mail = :mail");
        $stmt->bindValue(":mail", $mail, PDO::PARAM_STR);
        $stmt->bindValue(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function crearResponsable($responsable) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("INSERT INTO responsable (tipo, apellido, nombre, fechaNacimiento, sexo, mail, telefono, direccion)
            VALUES (
                :tipo,
                :apellido,
                :nombre,
                :fechaNacimiento,
                :sexo,
                :mail,
                :telefono,
                :direccion)");
        $stmt->bindValue(":tipo", $responsable['tipo'], PDO::PARAM_STR);
        $stmt->bindValue(":apellido", $responsable['apellido'], PDO::PARAM_STR);
        $stmt->bindValue(":nombre", $responsable['nombre'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaNacimiento", $responsable['fechaNacimiento'], PDO::PARAM_STR);
        $stmt->bindValue(":sexo", $responsable['sexo'], PDO::PARAM_STR);
        $stmt->bindValue(":mail", $responsable['mail'], PDO::PARAM_STR);
        $stmt->bindValue(":telefono", $responsable['telefono'], PDO::PARAM_STR);
        $stmt->bindValue(":direccion", $responsable['direccion'], PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

}

?>