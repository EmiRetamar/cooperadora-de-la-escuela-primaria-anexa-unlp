<?php

require_once 'PDOConnection.php';

class Usuario_model {

    private  $id;
    private  $username;
    private  $password;
    private  $habilitado;
    private  $rol;
    private  $mail;
    private  $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getId() {
        return ($this->id);
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getUsername() {
        return ($this->username);
    }

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getPassword() {
        return ($this->password);
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    public function getHabilitado() {
        return ($this->habilitado);
    }

    public function setHabilitado($habilitado) {
        $this->habilitado = $habilitado;
    }

    public function getRol() {
        return ($this->rol);
    }

    public function setRol($rol) {
        $this->rol = $rol;
    }

    public function getMail() {
        return ($this->mail);
    }

    public function setMail($mail) {
        $this->mail = $mail;
    }

    public function login($username, $password) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM usuario WHERE username = :username AND password = :password");
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->bindValue(':password', $password, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($row = $stmt->fetch()) {
            $this->setId($row['id']);
            $this->setUsername($row['username']);
            $this->setPassword($row['password']);
            $this->setHabilitado($row['habilitado']);
            $this->setRol($row['rol']);
            $this->setMail($row['mail']);
            return (true);
        }
        else {
            return (false);
        }
    }

    public function estaHabilitado() {
        return ($this->getHabilitado());
    }

    // Cuando se va a dar de alta un usuario, se verifica si existe en el sistema un usuario con el mismo username

    public function existeUsernameUsuario($username) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT username FROM usuario WHERE username = :username");
        $stmt->bindParam(":username", $username, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    // Cuando se va a dar de alta un usuario, se verifica si existe en el sistema un usuario con el mismo mail

    public function existeMailUsuario($mail) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT mail FROM usuario WHERE mail = :mail");
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    // Cuando se va a modificar un usuario , se verifica si existe otro usuario con el username ingresado

    public function existeOtroUsernameUsuarioIgual($idUsuario, $username) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT username FROM usuario WHERE id <> :idUsuario AND username = :username");
        $stmt->bindParam(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->bindParam(":username", $username, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    // Cuando se va a modificar un usuario , se verifica si existe otro usuario con el mail ingresado

    public function existeOtroMailUsuarioIgual($idUsuario, $mail) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT mail FROM usuario WHERE id <> :idUsuario AND mail = :mail");
        $stmt->bindParam(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    public function existeUsuario($idUsuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT id FROM usuario WHERE id = :idUsuario");
        $stmt->bindParam(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    public function obtenerUsuario($idUsuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM usuario WHERE id = :idUsuario");
        $stmt->bindParam(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt->fetch());
        }
        else {
            return (false);
        }
    }

    public function obtenerIdUsuario($username) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT id FROM usuario WHERE username = :username");
        $stmt->bindParam(":username", $username, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt->fetchColumn()); // Lo que hace fetchColumn() es devolver una única columna de la siguiente fila de un conjunto de resultados. Por ejemplos si se tienen 2 filas y se lo usa la primera vez devuelve un dato de la primera fila y si se lo usa otra vez devuelve un dato de la segunda fila. Si se le ingresa un parametro fetchColumn(1) lo que hace es devolver la segunda columna de la siguiente fila. En este caso devuelve la primera columna de la primera fila porque se usa una vez y tenemos una sola fila
        }
        else {
            return (false);
        }
    }

    public function crearUsuario($usuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("INSERT INTO usuario (username, password, habilitado, rol, mail)
            VALUES (
                :username,
                :password,
                :habilitado,
                :rol,
                :mail)");
        $stmt->bindValue(":username", $usuario['username'], PDO::PARAM_STR);
        $stmt->bindValue(":password", $usuario['password'], PDO::PARAM_STR);
        $stmt->bindValue(":habilitado", $usuario['habilitado'], PDO::PARAM_STR);
        $stmt->bindValue(":rol", $usuario['rol'], PDO::PARAM_STR);
        $stmt->bindValue(":mail", $usuario['mail'], PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function modificarUsuario($idUsuario, $usuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("UPDATE usuario
            set
                username = :username,
                password = :password,
                habilitado = :habilitado,
                rol = :rol,
                mail = :mail
            WHERE id = :idUsuario");
        $stmt->bindValue(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->bindValue(":username", $usuario['username'], PDO::PARAM_STR);
        $stmt->bindValue(":password", $usuario['password'], PDO::PARAM_STR);
        $stmt->bindValue(":habilitado", $usuario['habilitado'], PDO::PARAM_STR);
        $stmt->bindValue(":rol", $usuario['rol'], PDO::PARAM_STR);
        $stmt->bindValue(":mail", $usuario['mail'], PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function eliminarUsuario($idUsuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("DELETE FROM usuario WHERE id = :idUsuario");
        $stmt->bindValue(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function getUsuarioByUsername($username){
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM usuario WHERE username = :username");
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($row = $stmt->fetch()) {
            $this->setId($row['id']);
            $this->setUsername($row['username']);
            $this->setPassword($row['password']);
            $this->setHabilitado($row['habilitado']);
            $this->setRol($row['rol']);
            $this->setMail($row['mail']);
            return $this;
        }
        else {
            return (false);
        }
    }

}

?>