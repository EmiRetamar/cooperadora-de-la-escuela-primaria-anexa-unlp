<?php

require_once 'PDOConnection.php';

class Listado_model {

    private $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function listarUsuarios() {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM usuario");
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) { 
            return ($stmt);
        }
        else {
            return (false);
        }
    }
    
    public function listarAlumnos() {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM alumno");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarResponsables() {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM responsable");
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function obtenerResponsablesNoAsignados($idAlumno) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT DISTINCT id, tipo, apellido, nombre, mail FROM responsable LEFT JOIN alumnoResponsable
            ON (responsable.id = alumnoResponsable.idResponsable)
            WHERE alumnoResponsable.idAlumno <> :idAlumno");
        $stmt->bindValue(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasExistentes() {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM cuota");
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasPagas($aluID) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare(
            "SELECT *, pago.becado as becado
                FROM cuota
                INNER JOIN pago on (cuota.id = pago.idCuota)
                WHERE pago.idAlumno = :idAlumno AND cuota.id IN (
                    SELECT pago.idCuota
                        FROM pago
                        where pago.idAlumno = :idAlumno)
                ORDER BY cuota.anio DESC, cuota.mes DESC");
        $stmt->bindValue(":idAlumno", $aluID, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasImpagas($aluID) {  
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare(
            "SELECT * 
            FROM cuota
            WHERE cuota.id NOT IN(SELECT pago.idCuota
                                FROM pago
                                WHERE pago.idAlumno = :idAlumno)
            ORDER BY cuota.anio ASC, cuota.mes ASC");

        $stmt->bindValue(":idAlumno", $aluID, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion        
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarAlumnosConMatriculaPaga($idUsuario, $rolUsuario) { // La deben ver consultores, gestores y administradores, filtrar para los consultores y que muestre solo a sus alumnos       
        $conn = $this->pdo->getConnection();
        if ( $rolUsuario == 'consulta') {
            $stmt = $conn->prepare(
                "SELECT 
                    alumno.apellido, alumno.nombre, cuota.monto, cuota.mes, cuota.anio
                FROM 
                    responsable 
                    INNER JOIN alumnoResponsable 
                    INNER JOIN alumno 
                    INNER JOIN pago
                    INNER JOIN cuota
                WHERE 
                    responsable.id = :idUsuario
                    AND cuota.tipo = 1
                    AND responsable.id = alumnoResponsable.idResponsable 
                    AND alumnoResponsable.idAlumno = alumno.id 
                    AND pago.idAlumno = alumno.id
                    AND pago.idCuota = cuota.id
                ORDER BY cuota.anio ASC, cuota.mes ASC");
            $stmt->bindValue(":idUsuario", $idUsuario, PDO::PARAM_STR);
            $stmt->execute();
            $this->pdo->closeConnection($conn); // Cerramos la conexion            
            if($stmt->rowCount() > 0) {
                return ($stmt);
            }
            else {
                return (false);
            }

        }
        else{
            $stmt = $conn->prepare("SELECT * FROM alumno");
        }
    }

    public function listarMatriculasPagas() {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare(
            "SELECT DISTINCT alumno.numeroDocumento, alumno.nombre, alumno.apellido, cuota.numero, cuota.mes, cuota.anio, cuota.monto
                FROM alumno
                INNER JOIN pago ON (alumno.id = pago.idAlumno)
                INNER JOIN cuota ON (pago.idCuota = cuota.id)
                WHERE cuota.tipo = true
                ORDER BY cuota.mes ASC, cuota.anio ASC");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarMatriculasPagasResponsable($idUsuario) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare(
            "SELECT DISTINCT alumno.numeroDocumento, alumno.nombre, alumno.apellido, cuota.numero, cuota.mes, cuota.anio, cuota.monto
                FROM responsable
                INNER JOIN alumnoResponsable ON (responsable.id = alumnoResponsable.idResponsable)
                INNER JOIN alumno ON (alumnoResponsable.idAlumno = alumno.id)
                INNER JOIN pago ON (alumno.id = pago.idAlumno)
                INNER JOIN cuota ON (pago.idCuota = cuota.id)
                WHERE responsable.idUsuario = :idUsuario AND cuota.tipo = true
                ORDER BY cuota.mes ASC, cuota.anio ASC");
        $stmt->bindValue(":idUsuario", $idUsuario, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasImpagasResponsable($idResponsable){
        $conn = $this->pdo->getConnection();
        $year = date("Y");
        $month = date("m");
        $stmt = $conn->prepare(
            "SELECT DISTINCT alumno.nombre, alumno.apellido, cuota.id, cuota.anio, cuota.mes, cuota.monto
                FROM responsable
                INNER JOIN alumnoResponsable ON (responsable.id = alumnoResponsable.idResponsable)
                INNER JOIN alumno ON (alumnoResponsable.idAlumno = alumno.id)
                INNER JOIN pago ON (pago.idAlumno = alumno.id)
                INNER JOIN cuota
                WHERE responsable.idUsuario = :idResponsable
                AND cuota.tipo = 0
                AND cuota.anio <= :year
                AND cuota.mes < :month
                AND cuota.id NOT IN (
                    SELECT pago.idCuota
                        FROM pago
                        INNER JOIN alumno
                        WHERE pago.idAlumno = alumno.id)
                ORDER BY cuota.anio ASC, cuota.mes ASC");

        $stmt->bindValue(":idResponsable", $idResponsable, PDO::PARAM_STR);
        $stmt->bindValue(":year", $year, PDO::PARAM_STR);
        $stmt->bindValue(":month", $month, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion        
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasImpagasAdmin(){
        $conn = $this->pdo->getConnection();
        $year = date("Y");
        $month = date("m");
        $stmt = $conn->prepare(
            "SELECT DISTINCT alumno.nombre, alumno.apellido, cuota.id, cuota.anio, cuota.mes, cuota.monto
                FROM alumno
                INNER JOIN pago ON (pago.idAlumno = alumno.id)
                INNER JOIN cuota
                WHERE cuota.tipo = 0
                AND cuota.anio <= :year
                AND cuota.mes < :month
                AND cuota.id NOT IN (
                    SELECT pago.idCuota
                        FROM pago
                        INNER JOIN alumno
                        WHERE pago.idAlumno = alumno.id)
                ORDER BY cuota.anio ASC, cuota.mes ASC");

        $stmt->bindValue(":year", $year, PDO::PARAM_STR);
        $stmt->bindValue(":month", $month, PDO::PARAM_STR);
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasPagasResponsable($idResponsable){
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare(
            "SELECT DISTINCT alumno.nombre, alumno.apellido, cuota.id, cuota.anio, cuota.mes, cuota.monto, pago.becado
                FROM responsable
                INNER JOIN alumnoResponsable ON (responsable.id = alumnoResponsable.idResponsable)
                INNER JOIN alumno ON (alumnoResponsable.idAlumno = alumno.id)
                INNER JOIN pago ON (pago.idAlumno = alumno.id)
                INNER JOIN cuota ON (pago.idCuota = cuota.id)
                WHERE responsable.idUsuario = :idResponsable
                AND cuota.tipo = 0
                ORDER BY cuota.anio ASC, cuota.mes ASC");

        $stmt->bindValue(":idResponsable", $idResponsable, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion        
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function listarCuotasPagasAdmin(){
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare(
            "SELECT DISTINCT alumno.nombre, alumno.apellido, cuota.id, cuota.anio, cuota.mes, cuota.monto, pago.becado
                FROM alumno
                INNER JOIN pago ON (pago.idAlumno = alumno.id)
                INNER JOIN cuota ON (pago.idCuota = cuota.id)
                WHERE cuota.tipo = 0
                ORDER BY cuota.anio ASC, cuota.mes ASC");

        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return ($stmt);
        }
        else {
            return (false);
        }
    }

}

?>