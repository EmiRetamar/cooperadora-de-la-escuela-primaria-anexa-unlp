<?php

require_once 'PDOConnection.php';
require_once 'Alumno_model.php';

class Cuota_model {

    private $anio;
    private $mes;
    private $numero;
    private $monto;
    private $tipo;
    private $comisionCobrador;
    private $fechaAlta;
    private $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getAnio() {
        return ($this->anio);
    }

    public function setAnio($anio) {
        $this->anio = $anio;
    }

    public function getMes() {
        return ($this->mes);
    }

    public function setMes($mes) {
        $this->mes = $mes;
    }

    public function getNumero() {
        return ($this->numero);
    }

    public function setNumero($numero) {
        $this->numero = $numero;
    }

    public function getMonto() {
        return ($this->monto);
    }

    public function setMonto($monto) {
        $this->monto = $monto;
    }

    public function getTipo() {
        return ($this->tipo);
    }

    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function getComisionCobrador() {
        return ($this->comisionCobrador);
    }

    public function setComisionCobrador($comisionCobrador) {
        $this->comisionCobrador = $comisionCobrador;
    }

    public function getFechaAlta() {
        return ($this->fechaAlta);
    }

    public function setFechaAlta($fechaAlta) {
        $this->fechaAlta = $fechaAlta;
    }

    public function alumno_existe($idAlumno) { // Testeada
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT numeroDocumento FROM alumno WHERE id = ?");
        $stmt->bindParam(1, $idAlumno, PDO::PARAM_STR); // SQL INJECTION, 1 se refiere al primero (y unico en este caso) de los signos de interrogacion del $stmt
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if(!empty($stmt) and $stmt->rowCount() > 0) { // Cual es la diferencia en las condiciones? no son lo mismo las dos cosas?
            return ($stmt);
        }
        else {
            return (false);
        }
    }

    public function crearCuota($cuota) {
        $conn= $this->pdo->getConnection();
        $stmt= $conn->prepare("INSERT INTO cuota (anio, mes, numero, monto, tipo, comisionCobrador, fechaAlta) 
            VALUES (
                :anio, 
                :mes, 
                :numero, 
                :monto, 
                :tipo, 
                :comisionCobrador, 
                :fechaAlta)");
        $stmt->bindValue(":anio", $cuota['anio'], PDO::PARAM_STR);
        $stmt->bindValue(":mes", $cuota['mes'], PDO::PARAM_STR);
        $stmt->bindValue(":numero", $cuota['numero'], PDO::PARAM_STR);
        $stmt->bindValue(":tipo", $cuota['tipo'], PDO::PARAM_STR);
        $stmt->bindValue(":comisionCobrador", $cuota['comisionCobrador'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaAlta", $cuota['fechaAlta'], PDO::PARAM_STR);
        $stmt->bindValue(":monto", $cuota['monto'], PDO::PARAM_STR);
        $stmt->execute();
       // $conexion->close(); //cerramos la conexion.
    }

    public function modificarCuota($cuota) {
        $conn= $this->pdo->getConnection();
        $stmt= $conn->prepare("UPDATE cuota 
                set 
                    anio = :anio,
                    mes = :mes,
                    numero = :numero, 
                    monto = :monto, 
                    tipo = :tipo, 
                    comisionCobrador = :comisionCobrador, 
                    fechaAlta = :fechaAlta
                WHERE cuota.id = :id");      
            $stmt->bindValue(":id", $cuota['id'], PDO::PARAM_STR);
            $stmt->bindValue(":anio", $cuota['anio'], PDO::PARAM_STR);
            $stmt->bindValue(":mes", $cuota['mes'], PDO::PARAM_STR);
            $stmt->bindValue(":numero", $cuota['numero'], PDO::PARAM_STR);
            $stmt->bindValue(":tipo", $cuota['tipo'], PDO::PARAM_STR);
            $stmt->bindValue(":comisionCobrador", $cuota['comisionCobrador'], PDO::PARAM_STR);
            $stmt->bindValue(":fechaAlta", $cuota['fechaAlta'], PDO::PARAM_STR);
            $stmt->bindValue(":monto", $cuota['monto'], PDO::PARAM_STR);
            $stmt->execute();
            $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function existeCuota($idCuota) { // Testeada
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT id FROM cuota WHERE id = ?");
        $stmt->bindParam(1, $idCuota, PDO::PARAM_STR); 
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if(!empty($stmt) and $stmt->rowCount() > 0) { // Cual es la diferencia en las condiciones? no son lo mismo las dos cosas?
            return (true);
        }
        else {
            return (false);
        }
    }

    public function eliminarCuota($idCuota) { // Testeada
        $conn = $this->pdo->getConnection();
        if($this->existeCuota($idCuota)) {
            $stmt = $conn->prepare("DELETE FROM cuota WHERE id = :id");
            $stmt->bindValue(":id", $idCuota, PDO::PARAM_STR);
            $stmt->execute();
            $this->pdo->closeConnection($conn); // Cerramos la conexion
        }
        else {
            $this->pdo->closeConnection($conn); // Cerramos la conexion
            return false;
        }
    }


    
    public function pagarCuota($cuota) { 
        $conn = $this->pdo->getConnection();
        if($this->alumno_existe($cuota['idAlumno'])) {       
            $stmt= $conn->prepare("INSERT INTO pago (idAlumno, idCuota, becado, fechaAlta) 
                VALUES (
                    :idAlumno, 
                    :idCuota, 
                    :becado, 
                    CURDATE())");
            $stmt->bindValue(":idAlumno", $cuota['idAlumno'], PDO::PARAM_STR);
            $stmt->bindValue(":idCuota", $cuota['idCuota'], PDO::PARAM_STR);
            $stmt->bindValue(":becado", $cuota['becado'], PDO::PARAM_STR);
            $stmt->execute();
           // $conexion->close(); //cerramos la conexion.
        }
        else {
            $this->pdo->closeConnection($conn); // Cerramos la conexion
            return false;
        }
    }


    public function obtenerCuota($idCuota) {
        $conn = $this->pdo->getConnection();
            $stmt= $conn->prepare("SELECT * 
                                FROM cuota 
                                WHERE cuota.id = :id");
            $stmt->bindValue(":id", $idCuota, PDO::PARAM_STR);
            $stmt->execute();
            $this->pdo->closeConnection($conn); // Cerramos la conexion
            if(!empty($stmt) and $stmt->rowCount() > 0) { // Cual es la diferencia en las condiciones? no son lo mismo las dos cosas?
                return ($stmt->fetch());
            }
            else {
                return (false);
            }
    } 
}

?>