<?php

require_once 'PDOConnection.php';

class Configuracion_model {

    private  $titulo;
    private  $descripcion;
    private  $mail;
    private  $elementos;
    private  $habilitado;
    private  $mensajeEstado;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getTitulo() {
        return ($this->titulo);
    }

    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getDescripcion() {
        return ($this->descripcion);
    }

    public function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    public function getMail() {
        return ($this->mail);
    }

    public function setMail($mail) {
        $this->mail = $mail;
    }

    public function getElementos() {
        return ($this->elementos);
    }

    public function setElementos($elementos) {
        $this->elementos = $elementos;
    }

    public function getHabilitado() {
        return ($this->habilitado);
    }

    public function setHabilitado($habilitado) {
        $this->habilitado = $habilitado;
    }

    public function getMensajeEstado() {
        return ($this->mensajeEstado);
    }

    public function setMensajeEstado($mensajeEstado) {
        $this->mensajeEstado = $mensajeEstado;
    }

    public function cargarInfoCooperadora($conf) { 
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("UPDATE configuracion
            set
                titulo = :titulo,
                descripcion = :descripcion,
                mail = :mail,
                elementos = :elementos,
                habilitado = :habilitado,
                mensajeEstado = :mensajeEstado");
        $stmt->bindValue(":titulo", $conf['titulo'], PDO::PARAM_STR);
        $stmt->bindValue(":descripcion", $conf['descripcion'], PDO::PARAM_STR);
        $stmt->bindValue(":mail", $conf['mail'], PDO::PARAM_STR);
        $stmt->bindValue(":elementos", $conf['elementos'], PDO::PARAM_STR);
        $stmt->bindValue(":habilitado", $conf['habilitado'], PDO::PARAM_STR);
        $stmt->bindValue(":mensajeEstado", $conf['mensajeEstado'], PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function traerConfiguracion() {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM configuracion");
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) { // Cual es la diferencia en las condiciones? no son lo mismo las dos cosas?
            return ($stmt->fetchAll(PDO::FETCH_ASSOC));
        }
        else {
            return (false);
        }
    }

}

?>