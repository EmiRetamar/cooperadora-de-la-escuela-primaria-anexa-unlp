<?php

class PDOConnection {
    
    const username = "grupo_39";
    const pass = "M2MT9omFC7zsfvhI";
	const host = "localhost";
	const db = "grupo_39";

	function __construct() {

	}
    
    public function getConnection() {
    	$username = self::username;
    	$pass = self::pass;
    	$host = self::host;
    	$db = self::db;
    	try {
	    	$conexion = new PDO("mysql:host=$host;dbname=$db", $username, $pass);
			$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	        return ($conexion);
	    }
	    catch(Exception $e) {
	    	// En caso de que se quiera entrar por localhost va a venir por aca
			$username = "root";
			$pass = "";
	    	$conexion = new PDO("mysql:host=$host;dbname=$db", $username, $pass);
			$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	        return ($conexion);
		}
    }

    public function closeConnection($conn) {
    	$conn = null;
    	return (true);
    }

}

?>