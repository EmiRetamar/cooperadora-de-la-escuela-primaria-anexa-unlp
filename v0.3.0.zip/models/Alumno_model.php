<?php

require_once 'PDOConnection.php';

class Alumno_model {

    private  $id;
    private  $tipoDocumento;
    private  $numeroDocumento;
    private  $apellido;
    private  $nombre;
    private  $fechaNacimiento;
    private  $sexo;
    private  $mail;
    private  $direccion;
    private  $fechaIngreso;
    private  $fechaEgreso;
    private  $fechaAlta;
    private  $idPago;
    private  $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getId() {
        return ($this->id);
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getTipoDocumento() {
        return ($this->tipoDocumento);
    }

    public function setTipoDocumento($tipoDocumento) {
        $this->tipoDocumento = $tipoDocumento;
    }

    public function getNumeroDocumento() {
        return ($this->numeroDocumento);
    }

    public function setNumeroDocumento($numeroDocumento) {
        $this->numeroDocumento = $numeroDocumento;
    }

    public function getApellido() {
        return ($this->apellido);
    }

    public function setApellido($apellido) {
        $this->apellido = $apellido;
    }

    public function getNombre() {
        return ($this->nombre);
    }

    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getFechaNacimiento() {
        return ($this->fechaNacimiento);
    }

    public function setFechaNacimiento($fechaNacimiento) {
        $this->fechaNacimiento = $fechaNacimiento;
    }

    public function getSexo($sexo) {
        return ($this->sexo);
    }

    public function setSexo($sexo) {
        $this->sexo = $sexo;
    }

    public function getMail() {
        return ($this->mail);
    }

    public function setMail($mail) {
        $this->mail = $mail;
    }

    public function getDireccion() {
        return ($this->direccion);
    }

    public function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

    public function getFechaIngreso() {
        return ($this->fechaIngreso);
    }

    public function setFechaIngreso($fechaIngreso) {
        $this->fechaIngreso = $fechaIngreso;
    }

    public function getFechaEgreso() {
        return ($this->fechaEgreso);
    }

    public function setFechaEgreso($fechaEgreso) {
        $this->fechaEgreso = $fechaEgreso;
    }

    public function getFechaAlta() {
        return ($this->fechaAlta);
    }

    public function setFechaAlta($fechaAlta) {
        $this->fechaAlta = $fechaAlta;
    }

    public function getIdPago() {
        return ($this->idPago);
    }

    public function setIdPago($idPago) {
        $this->idPago = $idPago;
    }

    // Cuando se va a dar de alta un alumno, se verifica si existe en el sistema un alumno con el mismo DNI

    public function existeDniAlumno($numeroDocumento) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT numeroDocumento FROM alumno WHERE numeroDocumento = :numeroDocumento");
        $stmt->bindParam(":numeroDocumento", $numeroDocumento, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    // Cuando se va a dar de alta un alumno, se verifica si existe en el sistema un alumno con el mismo mail

    public function existeMailAlumno($mail) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT mail FROM alumno WHERE mail = :mail");
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    // Cuando se va a modificar un alumno , se verifica si existe otro usuario con el DNI ingresado

    public function existeOtroDniAlumnoIgual($idAlumno, $numeroDocumento) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT numeroDocumento FROM alumno WHERE id <> :idAlumno AND numeroDocumento = :numeroDocumento");
        $stmt->bindParam(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->bindParam(":numeroDocumento", $numeroDocumento, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    // Cuando se va a modificar un alumno , se verifica si existe otro usuario con el mail ingresado

    public function existeOtroMailAlumnoIgual($idAlumno, $mail) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT mail FROM alumno WHERE id <> :idAlumno AND mail = :mail");
        $stmt->bindParam(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->bindParam(":mail", $mail, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    public function existeAlumno($idAlumno) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT id FROM alumno WHERE id = :idAlumno");
        $stmt->bindParam(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return (true);
        }
        else {
            return (false);
        }
    }

    public function obtenerAlumno($idAlumno) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT * FROM alumno WHERE id = :idAlumno");
        $stmt->bindParam(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt->fetch());
        }
        else {
            return (false);
        }
    }

    public function obtenerIdAlumno($numeroDocumento) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("SELECT id FROM alumno WHERE numeroDocumento = :numeroDocumento");
        $stmt->bindParam(":numeroDocumento", $numeroDocumento, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
        if($stmt->rowCount() > 0) {
            return ($stmt->fetchColumn()); // Lo que hace fetchColumn() es devolver una única columna de la siguiente fila de un conjunto de resultados. Por ejemplos si se tienen 2 filas y se lo usa la primera vez devuelve un dato de la primera fila y si se lo usa otra vez devuelve un dato de la segunda fila. Si se le ingresa un parametro fetchColumn(1) lo que hace es devolver la segunda columna de la siguiente fila. En este caso devuelve la primera columna de la primera fila porque se usa una vez y tenemos una sola fila
        }
        else {
            return (false);
        }
    }

    public function crearAlumno($alumno) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("INSERT INTO alumno (tipoDocumento, numeroDocumento, apellido, nombre, fechaNacimiento, sexo, mail, direccion, fechaIngreso, fechaAlta)
            VALUES (
                :tipoDocumento,
                :numeroDocumento,
                :apellido,
                :nombre,
                :fechaNacimiento,
                :sexo,
                :mail,
                :direccion,
                :fechaIngreso,
                :fechaAlta)");
        $stmt->bindValue(":tipoDocumento", $alumno['tipoDocumento'], PDO::PARAM_STR);
        $stmt->bindValue(":numeroDocumento", $alumno['numeroDocumento'], PDO::PARAM_STR);
        $stmt->bindValue(":apellido", $alumno['apellido'], PDO::PARAM_STR);
        $stmt->bindValue(":nombre", $alumno['nombre'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaNacimiento", $alumno['fechaNacimiento'], PDO::PARAM_STR);
        $stmt->bindValue(":sexo", $alumno['sexo'], PDO::PARAM_STR);
        $stmt->bindValue(":mail", $alumno['mail'], PDO::PARAM_STR);
        $stmt->bindValue(":direccion", $alumno['direccion'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaIngreso", $alumno['fechaIngreso'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaAlta", $alumno['fechaAlta'], PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function modificarAlumno($idAlumno, $alumno) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("UPDATE alumno
            set
                tipoDocumento = :tipoDocumento,
                numeroDocumento = :numeroDocumento,
                apellido = :apellido,
                nombre = :nombre,
                fechaNacimiento = :fechaNacimiento,
                sexo = :sexo,
                mail = :mail,
                direccion = :direccion,
                fechaIngreso = :fechaIngreso
            WHERE id = :idAlumno");
        $stmt->bindValue(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->bindValue(":tipoDocumento", $alumno['tipoDocumento'], PDO::PARAM_STR);
        $stmt->bindValue(":numeroDocumento", $alumno['numeroDocumento'], PDO::PARAM_STR);
        $stmt->bindValue(":apellido", $alumno['apellido'], PDO::PARAM_STR);
        $stmt->bindValue(":nombre", $alumno['nombre'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaNacimiento", $alumno['fechaNacimiento'], PDO::PARAM_STR);
        $stmt->bindValue(":sexo", $alumno['sexo'], PDO::PARAM_STR);
        $stmt->bindValue(":mail", $alumno['mail'], PDO::PARAM_STR);
        $stmt->bindValue(":direccion", $alumno['direccion'], PDO::PARAM_STR);
        $stmt->bindValue(":fechaIngreso", $alumno['fechaIngreso'], PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function eliminarAlumno($idAlumno) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("DELETE FROM alumno WHERE id = :idAlumno");
        $stmt->bindValue(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

    public function asignarResponsable($idAlumno, $idResponsable) {
        $conn = $this->pdo->getConnection();
        $stmt = $conn->prepare("INSERT INTO alumnoResponsable (idAlumno, idResponsable)
            VALUES (
                :idAlumno,
                :idResponsable)");
        $stmt->bindValue(":idAlumno", $idAlumno, PDO::PARAM_STR);
        $stmt->bindValue(":idResponsable", $idResponsable, PDO::PARAM_STR);
        $stmt->execute();
        $this->pdo->closeConnection($conn); // Cerramos la conexion
    }

}

?>