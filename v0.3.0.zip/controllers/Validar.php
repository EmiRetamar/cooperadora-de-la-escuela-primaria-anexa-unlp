<?php

class Validar extends Controller {
	
	public function __construct()
	{
		session_start();

	}

	public function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	public function validarLogin($post){
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			  if (empty($_POST["username"])) {
			  		$userError = "El nombre de usuario es requerido.";
			  } else {
			    	$username = $this->test_input($_POST["username"]);
			    	if (!preg_match("/^[a-zA-Z ]*$/",$username)){
			            $userError = "Solo letras y espacios son permitidos";
			        }
			  }
				if (empty($_POST["password"]))
					$passError = "La contraseña es requerida.";
				else 
					$password = $this->test_input($_POST["password"]);
			
			$result = array();
			if ( isset($userError) )
				$result['userError'] = $userError;
			if (isset($passError))
				$result['userError'] = $userError;
			return $result;		
		}
		$goHome= $this->control('Home');
		$goHome->index();
	}

	public function validarOtraCosa($post){

	}

}

?>