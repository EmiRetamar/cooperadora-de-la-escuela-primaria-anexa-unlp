<?php

require_once 'twigAutoloader.php';

class Home extends Controller {

	public function __construct() {
		session_start(); 
    }

	public function index($parametro = '') {
        if($_SERVER['REQUEST_METHOD'] == 'GET') {
			$this->vistaFrontend();
		}
	}

	public function vistaFrontend() {
		$conf = $this->model('Configuracion_model');
		$datos = $conf->traerConfiguracion();
		$_SESSION['elementos'] = $datos[0]['elementos'];		
		$template = loadTwig("frontend.twig", $datos); // Carga el template. Por la configuracion de twigAutoloader.php
		if (isset ($_SESSION['username']))
			$template->display(array('sesion' => $_SESSION));
		else
			$template->display(array());
	}

	public function vistaBackend() {
		if(isset($_SESSION['id'])) {
	        $template = loadTwig("backend.twig", $_SESSION['elementos']); // Carga el template. Por la configuracion de twigAutoloader.php
	        $template->display(array());
		}
		else
			header('Location: ../');
	}

}

?>