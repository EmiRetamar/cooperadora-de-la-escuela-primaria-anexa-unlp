<?php

class Login extends Controller {

    public function __construct() {
        
    }

    public function index($parametro = '') {
        $template = loadTwig("login.twig", $parametro); // Carga el template. Por la configuracion de twigAutoloader.php
        $template->display(array());
    }

	public function login() {
        $_SESSION['loginError'] = ""; // Limpio de posibles errores
        $gateKeeper = $this->controlador('Validar');
        $validate = $gateKeeper->validarLogin($_POST);

        if(!isset($validate['userError']) AND !isset($validate['passError'])) {
        	$username = $_POST["username"];
        	$password = $_POST["password"];
            $user = $this->model('Usuario_model');
            if($user->login($username, $password)) { // Retorna true o false
                if($user->estaHabilitado()) {
                    session_start(); // Crea la sesion
                    $_SESSION['id'] = $user->getId();
                    $_SESSION['username'] = $user->getUsername();
                    $_SESSION['rol'] = $user->getRol();
                    $_SESSION['mail'] = $user->getMail();                
                    header('Location: ../Home/vistaBackend');
                }
                else {
                    $mensaje = "Usted tiene su cuenta deshabilitada";
                    $this->index($mensaje);
                }
        	}
        	else {
                $mensaje = "Usuario o contraseña incorrecta"; // Seteo en la variable Session, cargada en twigAutoloader.php para que se vea reflejado en la vista
                $this->index($mensaje);
        	}
        }
        else {
           $mensaje = "Contraseña o nombre de usuario incorrecta"; // Seteo en la variable Session, cargada en twigAutoloader.php para que se vea reflejado en la vista
            $this->index($mensaje);
        }
    }

}

?>