<?php

class Alumno extends Controller {

    public function __construct() {
        session_start();
    }

    // Carga bloque de twig en el backend

    public function controlAlumno() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                $listado = $this->model('Listado_model');
                $alumnos = $listado->listarAlumnos();
                $template = loadTwig("ABMAlumno.twig", $_SESSION['elementos']);
                $template->display(array('alumnos' => $alumnos));
            }
            else
                header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
        }
        else
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }

    // Se cargan las vistas del backend
    
    public function vistaAltaAlumno($parametro = '') {
        if(isset($_SESSION['id'])) { // Si el usuario esta logueado
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                $template = loadTwig("altaAlumno.twig", $parametro);
                $template->display(array());
            }
            else {
                header('Location: ../Home/vistaBackend');
            }
        }
        else {
            header('Location: ../');
        }
    }

    public function vistaModificarAlumno($parametro = '') {
        if(isset($_SESSION['id'])) { // Si el usuario esta logueado
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                if($_SERVER['REQUEST_METHOD'] == 'POST') {
                    // Caso en el que entra correctamente desde un llamado de la vista anterior
                    $idAlumno = $_POST['idAlumno'];
                    $alumnoModel = $this->model('Alumno_model');
                    // Si existe el alumno se lo obtiene y se carga el formulario, sino vuelve a la vista anterior
                    if($alumnoModel->existeAlumno($idAlumno)) {
                        $alumno = $alumnoModel->obtenerAlumno($idAlumno);
                        $template = loadTwig("modificarAlumno.twig", $parametro);
                        $template->display(array('alumno' => $alumno));
                    }
                    else {
                        // Caso en el que se quiere acceder con un parametro a traves de la url, y ese id de alumno mandado no existe
                        header('Location: controlAlumno');
                    }
                }
                else {
                    // Caso en el que se quiere acceder sin parametros, a traves de la url
                    header('Location: controlAlumno');
                }
            } 
            else {
                // Caso en el que el usuario no sea administrador
                header('Location: ../Home/vistaBackend');
            }
        }
        else {
            // Caso en el que el usuario no este logueado
            header('Location: ../');
        }
    }

    public function vistaListadoCuotasPagas() {
            $template = loadTwig("altaCuota.twig");
            $template->display(array());
    }

    public function vistaListadoCuotasImpagas() {
            $template = loadTwig("altaCuota.twig");
            $template->display(array());
    }

    // Funcionalidades llamadas desde las vistas

    public function agregarAlumnoResponsable() {
        if(isset($_GET['tipoDocumento']) && isset($_GET['numeroDocumento']) && isset($_GET['apellido']) && isset($_GET['nombre']) && isset($_GET['apellido']) && isset($_GET['fechaNacimiento']) && isset($_GET['sexo']) && isset($_GET['mail']) && isset($_GET['direccion']) && isset($_GET['fechaIngreso']) && isset($_GET['fechaAlta']) && isset($_GET['cantidadResponsables'])) {
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Parte alumno. Se obtiene los datos de la url por get, se da de alta el alumno y se le obtiene el id para luego relacionarlo con sus responsables correspondientes 
                $alumno = [
                "tipoDocumento" => $_GET["tipoDocumento"],
                "numeroDocumento" => $_GET["numeroDocumento"],
                "apellido" => $_GET["apellido"],
                "nombre" => $_GET["nombre"],
                "fechaNacimiento" => $_GET["fechaNacimiento"],
                "sexo" => $_GET["sexo"],
                "mail" => $_GET["mail"],
                "direccion" => $_GET["direccion"],
                "fechaIngreso" => $_GET["fechaIngreso"],
                "fechaAlta" => $_GET['fechaAlta']
                ];
                $alumnoModel = $this->model('Alumno_model');
                // Si el alumno no existe lo crea
                if(!$alumnoModel->existeDniAlumno($alumno['numeroDocumento'])) {
                    if(!$alumnoModel->existeMailAlumno($alumno['mail'])) {
                        $alumnoModel->crearAlumno($alumno);
                        $idAlumno = $alumnoModel->obtenerIdAlumno($alumno['numeroDocumento']);
                        // Parte responsables. Se obtienen los datos por post de cada uno de los responsables, se dan de alta y se les obtiene el id para relacionarlos con su alumno correspondiente
                        $cantidadResponsables = $_GET["cantidadResponsables"];
                        for($i = 1; $i <= $cantidadResponsables; $i++) {
                            $responsable = [
                            "tipo" => $_POST["tipo".$i],
                            "apellido" => $_POST["apellido".$i],
                            "nombre" => $_POST["nombre".$i],
                            "fechaNacimiento" => $_POST["fechaNacimiento".$i],
                            "sexo" => $_POST["sexo".$i],
                            "mail" => $_POST["mail".$i],
                            "telefono" => $_POST['telefono'.$i],
                            "direccion" => $_POST["direccion".$i]
                            ];
                            $responsableModel = $this->model('Responsable_model');
                            // Si el responsable no existe lo crea
                            if(!$responsableModel->existeMailResponsable($responsable['mail'])) {
                                $responsableModel->crearResponsable($responsable);
                                $idResponsable = $responsableModel->obtenerIdResponsable($responsable['mail']);
                                // Relaciona el alumno con el responsable numero $i
                                $alumnoModel->asignarResponsable($idAlumno, $idResponsable);
                            }
                            else {
                                $mensaje = 'El responsable '.$responsable['apellido'].' '.$responsable['nombre'].' ya existe, su mail: '.$responsable['mail'].' ya esta registrado en el sistema';
                                $this->vistaAltaAlumno($mensaje);
                            }
                            header('Location: controlAlumno');
                        }
                    }
                    else {
                        $mensaje = 'No se pudo crear el alumno debido a que el mail '.$alumno['mail'].' ya esta registrado en el sistema';
                        $this->vistaAltaAlumno($mensaje);
                    }
                }
                else {
                    $mensaje = $mensaje = 'No se pudo crear el alumno debido a que el DNI '.$alumno['numeroDocumento'].' ya esta registrado en el sistema';
                    $this->vistaAltaAlumno($mensaje);
                }
            }
            else {
                header('Location: controlAlumno');
            }
        }
        else {
            header('Location: controlAlumno');
        }
    }

    public function modificarAlumno() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $idAlumno = $_POST['idAlumno'];
            $alumno = [
            "tipoDocumento" => $_POST["tipoDocumento"],
            "numeroDocumento" => $_POST["numeroDocumento"],
            "apellido" => $_POST["apellido"],
            "nombre" => $_POST["nombre"],
            "fechaNacimiento" => $_POST["fechaNacimiento"],
            "sexo" => $_POST["sexo"],
            "mail" => $_POST["mail"],
            "direccion" => $_POST["direccion"],
            "fechaIngreso" => $_POST["fechaIngreso"],
            ];
            $alumnoModel = $this->model('Alumno_model'); // Genera una instancia de Alumno_model (new Alumno_model)
            // Si el alumno existe lo modifica
            if($alumnoModel->existeAlumno($idAlumno)) {
                // Si el DNI ingresado no existe se modifica el alumno, si ya existe en el sistema no se modifica el alumno y muestra un error (no tiene en cuenta el DNI del propio alumno a modificar)
                if(!$alumnoModel->existeOtroDniAlumnoIgual($idAlumno, $alumno['numeroDocumento'])) {
                    // Si el mail ingresado no existe se modifica el alumno, si ya existe en el sistema no se modifica el alumno y muestra un error (no tiene en cuenta el mail del propio alumno a modificar)
                    if(!$alumnoModel->existeOtroMailAlumnoIgual($idAlumno, $alumno['mail'])) {
                        $alumnoModel->modificarAlumno($idAlumno, $alumno);
                        header('Location: controlAlumno');
                    }
                    // Else de que el mail ya existe
                    else {
                        $mensaje = 'No se pudo modificar el alumno debido a que el mail '.$alumno['mail'].' ya esta registrado en el sistema';
                        $this->vistaModificarAlumno($mensaje);
                    }
                }
                // Else de que el DNI ya existe
                else {
                    $mensaje = 'No se pudo modificar el alumno debido a que el DNI '.$alumno['numeroDocumento'].' ya esta registrado en el sistema';
                    $this->vistaModificarAlumno($mensaje);      
                    }
            }
            // Else de que no existe el alumno
            else {
                $mensaje = 'Error, el alumno que usted quiere modificar no existe en el sistema';
                $this->vistaModificarAlumno($mensaje);
            }
        }
        // Else de que no hay un envio por POST
        else {
            header('Location: controlAlumno');
        }
    }

    public function eliminarAlumno() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $idAlumno = $_POST['idAlumno'];
            $alumnoModel = $this->model('Alumno_model');
            // Si existe el alumno, lo elimina
            if($alumnoModel->existeAlumno($idAlumno)) {
                $alumnoModel->eliminarAlumno($idAlumno);
            }
            header('Location: controlAlumno');
        }
        else {
            header('Location: controlAlumno');
        }
    }

    public function matriculasPagas() {
       if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador" or $_SESSION['rol'] == "gestion") {
                $listado = $this->model('Listado_model');
                $matriculas = $listado->listarMatriculasPagas();
                $template = loadTwig("listadoAlumnosMatriculasPagas.twig", $_SESSION['elementos']);
                $template->display(array('matriculas' => $matriculas));
            }
            else {
                $listado = $this->model('Listado_model');                
                $matriculas = $listado->listarMatriculasPagasResponsable($_SESSION['id']);
                $template = loadTwig("listadoAlumnosMatriculasPagasResponsable.twig", $_SESSION['elementos']);
                $template->display(array('matriculas' => $matriculas));
            }
        }
        else 
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }

    public function cuotasPagas() {
        // TODO. Si lo mira un responsable, es decir un usuario consulta, lo logico seria que solo vea la matricula paga de su alumno a cargo y no todo el listado.
    }
    
    public function cuotasImpagasResonsable() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador" or $_SESSION['rol'] == "gestion" ) { // Si el usuario es administrador
                $listado = $this->model('Listado_model');                
                $cuotas = $listado->listarCuotasImpagasAdmin();
                $template = loadTwig("listadoAlumnosCuotasImpagasResp.twig", $_SESSION['elementos']);
                $template->display(array('cuotas' => $cuotas));
            }
            else {
                $listado = $this->model('Listado_model');                
                $cuotas = $listado->listarCuotasImpagasResponsable($_SESSION['id']);
                $template = loadTwig("listadoAlumnosCuotasImpagasResp.twig", $_SESSION['elementos']);
                $template->display(array('cuotas' => $cuotas));
            }
        }
        else 
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }

    public function cuotasPagasResponsable() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
                if($_SESSION['rol'] == "administrador" or $_SESSION['rol'] == "gestion" ) { // Si el usuario es administrador
                    $listado = $this->model('Listado_model');                
                    $cuotas = $listado->listarCuotasPagasAdmin();
                    $template = loadTwig("listadoAlumnosCuotasPagasResp.twig", $_SESSION['elementos']);
                    $template->display(array('cuotas' => $cuotas));
                } 
                else {
                    $listado = $this->model('Listado_model');                
                    $cuotas = $listado->listarCuotasPagasResponsable($_SESSION['id']);
                    $template = loadTwig("listadoAlumnosCuotasPagasResp.twig", $_SESSION['elementos']);
                    $template->display(array('cuotas' => $cuotas));
                }
            }
            else 
                header('Location: ../'); // Redirigir a otro lado porque no esta logueado
        }
}

?>