<?php

class Usuario extends Controller {

    public function __construct() {
        session_start();
    }

    // Carga bloque de twig en el backend

    public function controlUsuario() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                $listado = $this->model('Listado_model');
                $usuarios = $listado->listarUsuarios();
                $template = loadTwig("ABMUsuario.twig", $_SESSION['elementos']);
                $template->display(array('usuarios' => $usuarios));
            }
            else
                header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
        }
        else
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado     
    }

    // Se cargan las vistas del backend

    public function vistaAltaUsuario($parametro = '') {
        if(isset($_SESSION['id'])) { // Si el usuario esta logueado
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                $template = loadTwig("altaUsuario.twig", $parametro);
                $template->display(array());
            }
            else {
                header('Location: ../Home/vistaBackend');
            }
        }
        else {
            header('Location: ../');
        }
    }

    public function vistaModificarUsuario($parametro = '') {
        if(isset($_SESSION['id'])) { // Si el usuario esta logueado
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                if($_SERVER['REQUEST_METHOD'] == 'POST') {
                    // Caso en el que entra correctamente desde un llamado de la vista anterior
                    $idUsuario = $_POST['idUsuario'];
                    $usuarioModel = $this->model('Usuario_model');
                    // Si existe el usuario se lo obtiene y se carga el formulario, sino vuelve a la vista anterior
                    if($usuarioModel->existeUsuario($idUsuario)) {
                        $usuario = $usuarioModel->obtenerUsuario($idUsuario);
                        $template = loadTwig("modificarUsuario.twig", $parametro);
                        $template->display(array('usuario' => $usuario));
                    }
                    else {
                        // Caso en el que el idUsuario no exista en la BD
                        header('Location: controlUsuario');
                    }
                }
                else {
                    // Caso en el que se quiere acceder a traves de la url
                    header('Location: controlUsuario');
                }
            }
            else {
                // Caso en el que el usuario no sea administrador
                header('Location: ../Home/vistaBackend');
            }
        }
        else {
            // Caso en el que el usuario no este logueado
            header('Location: ../');
        }
    }

    public function vistaEliminarUsuario($parametro = '') {
        if(isset($_SESSION['id'])) { // Si el usuario esta logueado
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                if($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $idUsuario = $_POST["idUsuario"];
                    $usuarioModel = $this->model('Usuario_model'); // Genera una instancia de Usuario_model (new Usuario_model)
                    // Si existe el usuario se lo obtiene y se carga el formulario, sino vuelve a la vista anterior
                    if($usuarioModel->existeUsuario($idUsuario)) {
                        $usuario = $usuarioModel->obtenerUsuario($idUsuario);
                        $template = loadTwig("eliminarUsuario.twig", $parametro);
                        $template->display(array('usuario' => $usuario));
                    }
                    else {
                        // Caso en el que se quiere acceder con un parametro a traves de la url, y ese id de usuario mandado no existe
                        header('Location: controlUsuario');
                    }
                }
                else {
                    // Caso en el que se quiere acceder a traves de la url
                    header('Location: controlUsuario');
                }
            }
            else {
                // Caso en el que el usuario no sea administrador
                header('Location: ../Home/vistaBackend');
            }
        }
        else {
            // Caso en el que el usuario no este logueado
            header('Location: ../');
        }
    }

    // Funcionalidades llamadas desde las vistas

    public function agregarUsuario() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $usuario = [
            "username" => $_POST["username"],
            "password" => $_POST["password"],
            "password2" => $_POST["password2"],
            "habilitado" => true,
            "rol" => $_POST["rol"],
            "mail" => $_POST["mail"]
            ];
            if($usuario['password'] == $usuario['password2']) {
                $usuarioModel = $this->model('Usuario_model'); // Genera una instancia de Usuario_model (new Usuario_model)
                // Para que se pueda dar de alta el usuario no debe existir el username ni el mail en la base de datos porque son campos unicos para cada usuario
                if(!$usuarioModel->existeUsernameUsuario($usuario['username'])) {
                    if(!$usuarioModel->existeMailUsuario($usuario['mail'])) {
                        $usuarioModel->crearUsuario($usuario);
                        // Si el rol del usuario es consulta hay que asignarle la cuenta a un responsable
                        if($usuario['rol'] == 'consulta') {
                            $responsableModel = $this->model('Responsable_model');
                            // Se trae el id del usuario recientemente creado para asignarlo a un responsable
                            $idUsuario = $usuarioModel->obtenerIdUsuario($usuario['username']);
                            // Si existe un responsable con el mail de la cuenta a crear
                            if($responsableModel->existeMailResponsable($usuario['mail'])) {
                                // Se le asigna a la cuenta de usuario su responsable correspondiente
                                $responsableModel->asignarCuenta($usuario['mail'], $idUsuario);
                            }
                            else {
                                // Se elimina la cuenta porque no se encontro responsable a asignar por lo tanto como es de consulta no deberia estar creada si no tiene un responsable asignado
                                $usuarioModel->eliminarUsuario($idUsuario);
                                $mensaje = 'No se pudo crear el usuario debido a que no se encontro un responsable con el mail '.$usuario['mail'].' para asignarle la cuenta';
                                $this->vistaAltaUsuario($mensaje);
                            }                            
                        }
                        header('Location: controlUsuario');
                    }
                    else {
                        $mensaje = 'No se pudo crear el usuario debido a que el mail '.$usuario['mail'].' ya esta registrado en el sistema';
                        $this->vistaAltaUsuario($mensaje);
                    }
                }
                else {
                    $mensaje = 'No se pudo crear el usuario debido a que el username '.$usuario['username'].' ya esta registrado en el sistema';
                    $this->vistaAltaUsuario($mensaje);
                }
            }
            else {
                $mensaje = "Las contraseñas no coinciden";
                $this->vistaAltaUsuario($mensaje);
            }
        }
        else {
            header('Location: controlUsuario');
        }
    }

    public function modificarUsuario() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $idUsuario = $_POST["idUsuario"];
            $usuario = [
            "username" => $_POST["username"],
            "password" => $_POST["password"],
            "password2" => $_POST["password2"],
            "habilitado" => $_POST["habilitado"],
            "rol" => $_POST["rol"],
            "mail" => $_POST["mail"]
            ];
            if($usuario['password'] == $usuario['password2']) {
                $usuarioModel = $this->model('Usuario_model'); // Genera una instancia de Usuario_model (new Usuario_model)
                // Si el usuario existe lo modifica
                if($usuarioModel->existeUsuario($idUsuario)) {
                    // Si el username ingresado no existe se modifica el usuario, si ya existe en el sistema no se modifica el usuario y muestra un error (no tiene en cuenta el username del propio usuario a modificar)
                    if(!$usuarioModel->existeOtroUsernameUsuarioIgual($idUsuario, $usuario['username'])) {
                        // Si el mail ingresado no existe se modifica el usuario, si ya existe en el sistema no se modifica el usuario y muestra un error (no tiene en cuenta el mail del propio usuario a modificar)
                        if(!$usuarioModel->existeOtroMailUsuarioIgual($idUsuario, $usuario['mail'])) {
                            $usuarioModel->modificarUsuario($idUsuario, $usuario);
                            header('Location: controlUsuario');
                        }
                        // Else de que el mail ya existe
                        else {
                            $mensaje = 'No se pudo modificar el usuario debido a que el mail '.$usuario['mail'].' ya esta registrado en el sistema';
                            $this->vistaModificarUsuario($mensaje);
                        }
                    }
                    // Else de que el username ya existe
                    else {
                        $mensaje = 'No se pudo modificar el usuario debido a que el username '.$usuario['username'].' ya esta registrado en el sistema';
                        $this->vistaModificarUsuario($mensaje);    
                    }
                }
                // Else de que no existe el usuario
                else {
                    $mensaje = 'Error, el usuario que usted quiere modificar no existe en el sistema';
                    $this->vistaModificarUsuario($mensaje);
                }
            }
            else {
                $mensaje = "Las contraseñas no coinciden";
                $this->vistaModificarUsuario($mensaje);
            }
        }
        // Else de que no hay un envio por POST
        else {
            header('Location: controlUsuario');
        }
    }

    public function eliminarUsuario() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $idUsuario = $_POST['idUsuario'];
            if($idUsuario != $_SESSION['id']) {
                $usuarioModel = $this->model('Usuario_model');
                $usuarioModel->eliminarUsuario($idUsuario);
                header('Location: controlUsuario');
            }
            else {
                $mensaje = "Error, usted no puede autoeliminarse";
                $this->vistaEliminarUsuario($mensaje);
            }
        }
        else {
            header('Location: controlUsuario');
        }
    }

}

?>