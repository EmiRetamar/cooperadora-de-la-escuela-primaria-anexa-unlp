<?php

class Responsable extends Controller {

    public function __construct() {
        session_start();
    }

    // Carga bloque de twig en el backend

    public function controlResponsable() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                $listado = $this->model('Listado_model');
                $responsables = $listado->listarResponsables();
                $template = loadTwig("ABMResponsable.twig", $_SESSION['elementos']);
                $template->display(array('responsables' => $responsables));
            }
            else
                header('Location: ../'); // Redirigir a otro lado porque no es administrador
        }
        else
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }

    // Se cargan las vistas del backend
    
    public function vistaAltaResponsable() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $alumno = [
            "tipoDocumento" => $_POST["tipoDocumento"],
            "numeroDocumento" => $_POST["numeroDocumento"],
            "apellido" => $_POST["apellido"],
            "nombre" => $_POST["nombre"],
            "fechaNacimiento" => $_POST["fechaNacimiento"],
            "sexo" => $_POST["sexo"],
            "mail" => $_POST["mail"],
            "direccion" => $_POST["direccion"],
            "fechaIngreso" => $_POST["fechaIngreso"],
            "fechaAlta" => date("Y-m-d"),
            "cantidadResponsables" => $_POST["cantidadResponsables"]
            ];
            $template = loadTwig("altaResponsable.twig");
            $template->display(array('alumno' => $alumno));
        }
    }

    // Funcionalidades llamadas desde las vistas

    public function agregarResponsable() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $array = [
            "tipo" => $_POST["tipo"],
            "apellido" => $_POST["apellido"],
            "nombre" => $_POST["nombre"],
            "fechaNacimiento" => $_POST["fechaNacimiento"],
            "sexo" => $_POST["sexo"],
            "mail" => $_POST["mail"],
            "telefono" => $_POST['telefono'],
            "direccion" => $_POST["direccion"]
            ];
            $responsable = $this->model('Responsable_model'); // Genera una instancia de Alumno_model (new Alumno_model)
            $responsable->crearResponsable($array);
            $this->controlResponsable();
        }
        else {
            $this->controlResponsable();
        }
    }

}

?>