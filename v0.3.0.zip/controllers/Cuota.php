<?php

class Cuota extends Controller {

    function __construct() {
        session_start();
    }

    // Se cargan las vistas del backend


    public function controlCuotaTodas() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador" or $_SESSION['rol'] == "gestion" ) { // Si el usuario es administrador
                $listado = $this->model('Listado_model');
                $cuotas = $listado->listarCuotasExistentes();
                $template = loadTwig("ABMCuota.twig", $_SESSION['elementos']);
                $template->display(array('listaCuotas' => $cuotas));
            }
            else 
                header('Location: ../'); // Redirigir a otro lado porque no es administrador
        }
        else 
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }


    public function controlCuotaAlumno() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if(isset($_SESSION['id'])) { // Si existe una sesion
                if($_SESSION['rol'] == "administrador" or $_SESSION['rol'] == "gestion" ) { // Si el usuario es administrador
                    $listado = $this->model('Listado_model');
                    //cargo las impagas
                    $cuotasImpagas = $listado->listarCuotasImpagas($_POST['aluID']);
                    $datos[0]= $_POST['aluID'];
                    $datos[1]= $cuotasImpagas;
                    $template = loadTwig("ABMCuotasImpagas.twig", $_SESSION['elementos']);
                    $template->display(array('datos' => $datos));
                    //cargo las pagas 
                    $cuotasPagas = $listado->listarCuotasPagas($_POST['aluID']);
                    $datos[1]= $cuotasPagas;
                    $template = loadTwig("ABMCuotasPagas.twig", $_SESSION['elementos']);
                    $template->display(array('datos' => $datos));
                }
                else 
                    header('Location: ../'); // Redirigir a otro lado porque no es administrador
            }
            else 
                header('Location: ../'); // Redirigir a otro lado porque no esta logueado }
        }
        else 
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }
    
    public function vistaAltaCuota() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador        
                $template = loadTwig("altaCuota.twig");
                $template->display(array());
            }
            else
                header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
        }
        else 
            header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
    }

    public function vistaModificarCuota() {
        if(isset($_SESSION['id'])) { // Si el usuario esta logueado
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                    // Caso en el que entra correctamente desde un llamado de la vista anterior
                    $cuotaModel = $this->model('Cuota_model');
                    // Si existe el usuario se lo obtiene y se carga el formulario, sino vuelve a la vista anterior
                    $cuota = $cuotaModel->obtenerCuota($_POST['id']);

                    $template = loadTwig("modificarCuota.twig", $cuota);
                    $template->display(array('cuota' => $cuota));
            }
            else {
                // Caso en el que el usuario no sea administrador
                header('Location: ../Home/vistaBackend');
            }
        }
        else {
            // Caso en el que el usuario no este logueado
            header('Location: ../');
        }
    }


    public function vistaBajaCuota() {
            $template = loadTwig("bajaCuota.twig");
            $template->display(array());
    }

    public function vistaRegistroAlumnos() {
            $listado = $this->model('Listado_model');
            $alumnos = $listado->listarAlumnos();
            $template = loadTwig("listadoAlumnosCuotas.twig", $_SESSION['elementos'] );
            $template->display(array('alumnos' => $alumnos));
    } 

    // Funcionalidades llamadas desde las vistas
    
    public function agregarCuota() { 
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $array = [
            "anio" => $_POST["anio"],
            "mes" => $_POST["mes"],
            "numero" => $_POST["numero"],
            "monto" => $_POST["monto"],
            "tipo" => $_POST["tipo"],
            "comisionCobrador" => $_POST["comisionCobrador"],
            "fechaAlta" => $_POST["fechaAlta"]
            ];
            $cuota = $this->model('Cuota_model'); // Genera una instancia de Cuota_model (new Cuota_model)
            $cuota->crearCuota($array);
            $this->controlCuotaTodas();
        }
        else
            $this->controlCuotaTodas();
    }

    public function modificarCuota() { 
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $array = [
            "id" => $_POST["id"],
            "anio" => $_POST["anio"],
            "mes" => $_POST["mes"],
            "numero" => $_POST["numero"],
            "monto" => $_POST["monto"],
            "tipo" => $_POST["tipo"],
            "comisionCobrador" => $_POST["comisionCobrador"],
            "fechaAlta" => $_POST["fechaAlta"],
            ];
            $cuota = $this->model('Cuota_model'); // Genera una instancia de Cuota_model (new Cuota_model)
            $cuota->modificarCuota($array);
            $this->controlCuotaTodas(); // Carga el template. Por la configuracion de twigAutoloader.php
        }
        else
            $this->controlCuotaTodas();
    }

    public function eliminarCuota() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $idCuota = $_POST['id'];
            $cuotaModel = $this->model('Cuota_model');
            // Si existe el alumno, lo elimina
            $cuotaModel->eliminarCuota($idCuota);
            header('Location: controlCuotaTodas');
        }
        else {
            header('Location: controlCuotaTodas');
        }
    }

    // Modulo Pago-Cuota
    
    public function pagarBecarAlumno($value='') {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {    
            if(isset($_POST['submit'])){
                if(!empty($_POST['check_list'])) {
                    if($_POST['submit'] == 'Becar'){
                        $esBecado = 1;
                    }
                    else
                        $esBecado = 0;
                    foreach($_POST['check_list'] as $idCuota) {
                        $this->pagarCuota($idCuota, $_POST['idAlumno'], $esBecado);                     
                    }
                    $this->vistaRegistroAlumnos(); 
                }
                else
                    echo "<b>Please Select Atleast One Option.</b>";    
            }
        }
        else
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
    }

    public function pagarCuota($idCuota, $idAlumno, $esBecado) { 
        if($_SERVER['REQUEST_METHOD'] == 'POST') {    
            if(isset($_POST['submit'])){        
                    $array = [
                    "idAlumno" => $idAlumno, // Esto no va en la tabla de cuota, pero lo coloco para verificar en el modelo de que se trata de un alumno existente.
                    "idCuota" => $idCuota,
                    "becado" => $esBecado
                    ];
                    $cuota = $this->model('Cuota_model'); // Genera una instancia de Cuotao_model (new Cuotao_model)
                    $cuota->pagarCuota($array); 
            }
            else
                header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
        }
        else 
            header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
    }    

}

?>