<?php

class Configuracion extends Controller {

    public function __construct() {
        session_start();

    }

    public function controlSitio() {
        if(isset($_SESSION['id'])) { // Si existe una sesion
            if($_SESSION['rol'] == "administrador") { // Si el usuario es administrador
                $conf = $this->model('Configuracion_model');
                $configuracion = $conf->traerConfiguracion();
                $template=loadTwig("configuracion.twig"); // Carga el template. Por la configuracion de twigAutoloader.php
                $template->display(array('conf' => $configuracion));
            }
            else
                header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
        }
        else
            header('Location: ../'); // Redirigir a otro lado porque no esta logueado
}

    public function infoCooperadora() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $array = [
            "titulo" => $_POST["titulo"],
            "descripcion" => $_POST["descripcion"],
            "mail" => $_POST["mail"],
            "elementos" => $_POST["elementos"],
            "habilitado" => $_POST["habilitado"],
            "mensaje" => $_POST["mensaje"]
            ];
            $conf = $this->model('Configuracion_model'); // Genera una instancia de Configuracion_model (new Configuracion_model)
            $conf->cargarInfoCooperadora($array);
            header('Location: ../Home');
        }
        else {
            header('Location: ../Home/vistaBackend'); // Redirigir a otro lado porque no es administrador
        }
    }

}

?>