<?php

class Controller
{

	public function model($model)
	{
		require_once '../aplicacion/models/' . $model . '.php';
		return new $model();
	}

	public function view($view, $data = []){
		require_once '../aplicacion/views/' .$view. '.php';
	}

}