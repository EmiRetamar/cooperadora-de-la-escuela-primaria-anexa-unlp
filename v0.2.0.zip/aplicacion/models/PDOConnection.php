<?php

class PDOConnection {
    
    const username = "root";
    const pass = "";
	const host ="localhost";
	const db = "grupo_39";

	function __construct() {
		
	}
    
    public function getConnection() {

    	$username = self::username;
    	$pass = self::pass;
    	$host = self::host;
    	$db = self::db;
    	
    	try {	        
	        $conexion = new PDO("mysql:host=$host;dbname=$db", $username, $pass);
			$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	        return ($conexion);
	    }
	    catch (Exception $e) {
			echo 'Error con la base de datos:'; // Pasar a la vista en una variable
			echo $e->getMessage(); // Quitar el echo
			die();
		}
    }

}

?>