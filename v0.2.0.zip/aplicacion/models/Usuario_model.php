<?php

require_once 'PDOConnection.php';

class Usuario_model {

    private  $id;
    private  $username;
    private  $password;
    private  $habilitado;
    private  $rol;
    private  $mail;
    var  $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getId() {
      return $this->id;
    }

    public function setId($id) {
      $this->id = $id;
    }

    public function getUsername() {
      return $this->username;
    }

    public function setUsername($username) {
      $this->username = $username;
    }

    public function getPassword() {
      return $this->password;
    }

    public function setPassword($password) {
      $this->password = $password;
    }

    public function getHabilitado() {
      return $this->habilitado;
    }

    public function setHabilitado($habilitado) {
      $this->habilitado = $habilitado;
    }

    public function getRol() {
      return $this->rol;
    }

    public function setRol($rol) {
      $this->rol = $rol;
    }

    public function getMail() {
      return $this->mail;
    }

    public function setMail($mail) {
      $this->mail = $mail;
    }

    public static function login($username, $password) {
        $conexionPDO = new PDOConnection();
        $conexion = $conexionPDO->getConnection();
        $query = $conexion->prepare('SELECT COUNT(*) FROM usuario WHERE username = :username AND password = :password');
        $query->bindValue(':username', $username, PDO::PARAM_STR);
        $query->bindValue(':password', $password, PDO::PARAM_STR);
        $query->execute();
        $conexion = NULL;
        if($query->fetchColumn() == 1) {
            $row = $query->fetch();
            $user = new Usuario_model();
            $user->setId($row['id']);
            $user->setUsername($row['username']);
            $user->setPassword($row['password']);
            $user->setHabilitado($row['habilitado']);
            $user->setRol($row['rol']);
            $user->setMail($row['mail']);
            return ($user);
        }
        else {
            return (null);
        }
    }

    public function usuario_existe($username) {
        $conn= $this->pdo->getConnection();
        
        $stmt= $conn->prepare("SELECT username FROM usuario WHERE username = ? ");
        $stmt->bindParam(1, $username, PDO::PARAM_STR); //SQL INJECTION, 1 se refiere al primero (y unico en este caso) de los signos de interrogacion del $stmt
        $stmt->execute();
        if (!empty($stmt) AND $stmt->rowCount() > 0) {
            return true;
        }
        else {
            return false;
        }
        
        $conn = null; //cerramos la conexion.
    }

    public function crearUsuario($user) {
        $conn= $this->pdo->getConnection();

        if (!$this->usuario_existe($user['username'])) {
            $stmt= $conn->prepare("INSERT INTO usuario (username, password, habilitado, rol, mail) 
                VALUES (
                    :username, 
                    :password, 
                    :habilitado, 
                    :rol,
                    :mail)");
            $stmt->bindValue(":username", $user['username'], PDO::PARAM_STR);
            $stmt->bindValue(":password", $user['password'], PDO::PARAM_STR);
            $stmt->bindValue(":habilitado", $user['habilitado'], PDO::PARAM_STR);
            $stmt->bindValue(":rol", $user['rol'], PDO::PARAM_STR);
            $stmt->bindValue(":mail", $user['mail'], PDO::PARAM_STR);
            $stmt->execute();

           // $conexion->close(); //cerramos la conexion.
        }
        else {
            return false;
        }
    }

    public function modificarUsuario($user) {
        $conn= $this->pdo->getConnection();

        if ($this->usuario_existe($user['username'])) {
        $stmt= $conn->prepare("UPDATE usuario 
                set 
                    password = :password, 
                    habilitado = :habilitado, 
                    rol = :rol,
                    mail = :mail
                WHERE username = :username");
            $stmt->bindValue(":username", $user['username'], PDO::PARAM_STR);
            $stmt->bindValue(":password", $user['password'], PDO::PARAM_STR);
            $stmt->bindValue(":habilitado", $user['habilitado'], PDO::PARAM_STR);
            $stmt->bindValue(":rol", $user['rol'], PDO::PARAM_STR);
            $stmt->bindValue(":mail", $user['mail'], PDO::PARAM_STR);
            $stmt->execute();
            $conn = null; //cerramos la conexion.
        }
        else {
            return false;
        }
    }

    public function eliminarUsuario($user) {
        $conn= $this->pdo->getConnection();

        if ($this->usuario_existe($user['username'])) {
        $stmt= $conn->prepare("UPDATE usuario 
                set 
                    habilitado = :habilitado
                WHERE username = :username");
            $stmt->bindValue(":username", $user['username'], PDO::PARAM_STR);
            $stmt->bindValue(":habilitado", $user['habilitado'], PDO::PARAM_STR);
            $stmt->execute();
            $conn = null; //cerramos la conexion.
        }
        else {
            return false;
        }
    }



}

?>