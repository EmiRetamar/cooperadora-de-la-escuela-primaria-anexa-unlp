<?php

require_once 'PDOConnection.php';

class Usuario_model {

    private  $clave;
    private  $cantidadElementos;
    private  $sitioHabilitado;
    private  $titulo;
    private  $descripcion;
    private  $mail;

    var  $pdo;

    function __construct() {
        $this->pdo = new PDOConnection();
    }

    public function getClave() {
      return $clave;
    }

    public function setClave($clave) {
      $this->$clave = $clave;
    }

    public function getCantidadElementos() {
      return $cantidadElementos;
    }

    public function setCantidadElementos($username) {
      $this->$cantidadElementos = $cantidadElementos;
    }

    public function getSitioHabilitado() {
      return $sitioHabilitado;
    }

    public function setSitioHabilitado($sitioHabilitado) {
      $this->$sitioHabilitado = $sitioHabilitado;
    }

    public function getTitulo() {
      return $titulo;
    }

    public function setTitulo($mail) {
      $this->$titulo = $titulo;
    }

    public function getDescripcion() {
      return $descripcion;
    }

    public function setDescripcion($descripcion) {
      $this->$descripcion = $descripcion;
    }

    public function getMail() {
      return $mail;
    }

    public function setMail($mail) {
      $this->$mail = $mail;
    }

    public function crearUsuario($user) {
        $conn= $this->pdo->getConnection();

        if (!$this->usuario_existe($user['username'])) {
            $stmt= $conn->prepare("INSERT INTO usuario (username, password, habilitado, rol) 
                VALUES (
                    :username, 
                    :password, 
                    :habilitado, 
                    :rol)");
            $stmt->bindValue(":username", $user['username'], PDO::PARAM_STR);
            $stmt->bindValue(":password", $user['password'], PDO::PARAM_STR);
            $stmt->bindValue(":habilitado", $user['habilitado'], PDO::PARAM_STR);
            $stmt->bindValue(":rol", $user['rol'], PDO::PARAM_STR);
            $stmt->execute();

           // $conexion->close(); //cerramos la conexion.
        }
        else {
            return false;
        }
    }

    public function modificarUsuario($user) {
        $conn= $this->pdo->getConnection();

        if ($this->usuario_existe($user['username'])) {
        $stmt= $conn->conexion->prepare("UPDATE usuario 
                set 
                    username = :username, 
                    password = :password, 
                    habilitado = :habilitado, 
                    rol = :rol ");      
            $stmt->bindValue(":username", $user['username'], PDO::PARAM_STR);
            $stmt->bindValue(":password", $user['password'], PDO::PARAM_STR);
            $stmt->bindValue(":habilitado", $user['habilitado'], PDO::PARAM_STR);
            $stmt->bindValue(":rol", $user['rol'], PDO::PARAM_STR);
            $stmt->execute();

            $conn = null; //cerramos la conexion.
        }
        else {
            return false;
        }
    }

    public static function login($username, $password) {
        echo 'Entro en login_model, ';
        $conexionPDO = new PDOConnection();
        $conexion = $conexionPDO->getConnection();
        $query = $conexion->prepare('SELECT COUNT(*) FROM usuario WHERE username = :username AND password = :password');
        $query->bindValue(':username', $username, PDO::PARAM_STR);
        $query->bindValue(':password', $password, PDO::PARAM_STR);
        $query->execute();
        $conexion = NULL;
        if($query->fetchColumn() == 1) {
            return (true);
        }
        else {
            return (false);
        }
    }

}

?>