<?php
require_once '../aplicacion/models/Usuario_model.php';
require_once '../aplicacion/controllers/twigAutoloader.php'; //Para cargar Twig

class Login extends Controller{

    function __construct() {
        
	}

    public function index($parametro1 = '')
    {
        $template=loadTwig("login.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
        $template->display(array());
        
    }

	public function login() {
    	$username = $_POST["username"]; // Deberia obtener los datos con POST
    	$password = $_POST["password"];
    	$user= Usuario_model::login($username, $password); 
        if($user != null) { // Retorna el usuario o null
            session_start();
            $_SESSION['id'] = $user->getId();
            $_SESSION['rol'] = $user->getRol();
    		$template=loadTwig("backend.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
            $template->display(array());
    	}
    	else {
            $this->index();
    		print('Los datos ingresados son incorrectos');
    	}
    }

    public function logout(){
        //TODO session_destroy();
    }

}

?>