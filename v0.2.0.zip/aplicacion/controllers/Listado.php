<?php
//require_once 'aplicacion/models/PDOConnection.php';
//require_once 'aplicacion/controllers/Usuario.php';
require_once '../aplicacion/controllers/twigAutoloader.php';  //Par cargar Twig


class Listado{
    public function index($param1 = '')
    {
        $template=loadTwig("listado.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
        $template->display(array());
    }

//Todos los listados deberán estar paginados según la configuración general del sistema
//y, según el caso, filtrar por los campos correspondientes previo a generarlos.

    public function matriculaPaga()
    {
		//TODO. Para el Rol de Consulta sólo se listarán los alumnos que tenga a cargo el responsable    }
    }
    
	public function cuotasPagadas($tipo)
    {
		//TODO. Si lo mira un responsable, es decir un usuario consulta, lo logico seria que solo vea la matricula paga de su alumno a cargo y no todo el listado.
    }

	public function cuotasImpagas($tipo)
    {
		//TODO. Si lo mira un responsable, es decir un usuario consulta, lo logico seria que solo vea la matricula paga de su alumno a cargo y no todo el listado.
    }
}

?>