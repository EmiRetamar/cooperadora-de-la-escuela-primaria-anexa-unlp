<?php
//require_once 'aplicacion/models/PDOConnection.php';
//require_once 'aplicacion/controllers/Usuario.php';
require_once 'twigAutoloader.php'; //Par cargar Twig


class Home extends Controller{
	/*
	function __construct() {

		/*$usr = new Usuario();
		$usr->agregarUsuario(); 

		$template=loadTwig("frontend.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
		$template->display(array());

	
	} */ 

	public function index($parametro1 = '')
	{
		$template=loadTwig("frontend.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
		$template->display(array());
	}

}

?>