<?php
function loadTwig($_plantilla){
        require_once("../aplicacion/lib/Twig/Autoloader.php");
        Twig_Autoloader::register();
        $templateDir="../aplicacion/views";
        $loader = new Twig_Loader_Filesystem($templateDir);
        $twig = new Twig_Environment($loader);
        $template = $twig->loadTemplate($_plantilla);
        return $template;
    }
?>