<?php
require_once '../aplicacion/controllers/twigAutoloader.php'; //Para cargar Twig

class Cuota {

    function __construct() {
        
	}

    public function index($parametro1 = '')
    {
    }

}

?>