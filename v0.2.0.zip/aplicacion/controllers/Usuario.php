<?php

require_once '../aplicacion/models/Usuario_model.php';
require_once '../aplicacion/controllers/twigAutoloader.php'; 

class Usuario extends Controller{

    function __construct() {
    	
    }

    public function index()
	{
        $template=loadTwig("ABMUsuario.twig");
        $template->display(array());
	}

        public function vistaAltaUsuario()
    {
        $template=loadTwig("altaUsuario.twig");
        $template->display(array());
    }

        public function vistaModificarUsuario()
    {
        $template=loadTwig("modificarUsuario.twig");
        $template->display(array());
    }
    
    public function vistaBajaUsuario()
    {
        $template=loadTwig("bajaUsuario.twig");
        $template->display(array());
    }


    public function agregarUsuario() {
   		$username = $_POST["username"];
    	$password = $_POST["password"];
		$rol = $_POST["rol"];

		$array = [
		"username" => $username,
		"password" => $password,
		"habilitado" => 1,
		"rol" => $rol
		];

		$user = new Usuario_model();
		$user->crearUsuario($array);

        $template=loadTwig("ABMUsuario.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
        $template->display(array());

    }

    public function modificarUsuario() {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $habilitado = $_POST["habilitado"];
        $mail = $_POST["mail"];
        $rol = $_POST["rol"];

        $array = [
        "username" => $username,
        "password" => $password,
        "habilitado" => $habilitado,
        "rol" => $rol,
        "mail" => $mail
        ];

        $user = new Usuario_model();
        $user->modificarUsuario($array);

        $template=loadTwig("ABMUsuario.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
        $template->display(array());
    }

    public function eliminarUsuario() {
        $username = $_POST["username"];
    	$habilitado = 0;
         $array = [
        "username" => $username,
        "habilitado" => $habilitado
        ];

        $user = new Usuario_model();
        $user->eliminarUsuario($array);

        $template=loadTwig("ABMUsuario.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
        $template->display(array());

    }


}

?>