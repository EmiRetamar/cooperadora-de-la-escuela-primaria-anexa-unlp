<?php
require_once '../aplicacion/controllers/twigAutoloader.php';  //Par cargar Twig


class Configuracion{
    public function index($param1 = '')
    {
        $template=loadTwig("configuracion.twig"); //Carga el template. Por la configuracion de twigAutoloader.php, los templates estan en entrega2/views.
        $template->display(array());
    }


    public function infoCooperadora()
    {
    }

	public function elementosPorPagina($tipo)
    {
    }

	public function estadoSitio($estado)
    {
    }
}

?>