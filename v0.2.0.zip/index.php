<?php

header("Location: anexa/index.php");
 


?>