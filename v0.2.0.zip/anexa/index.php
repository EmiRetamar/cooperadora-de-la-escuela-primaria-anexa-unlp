<?php

require_once '../aplicacion/init.php';

$app = new App;


?>